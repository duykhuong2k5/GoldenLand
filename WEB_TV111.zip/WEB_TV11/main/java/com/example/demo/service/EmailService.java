package com.example.demo.service;

public interface EmailService {
    void sendOtp(String to, String otp);
}