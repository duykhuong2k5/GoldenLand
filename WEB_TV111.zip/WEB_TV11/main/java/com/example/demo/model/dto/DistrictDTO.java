package com.example.demo.model.dto;

public class DistrictDTO {
    private Long[] Buildingids;

    public Long[] getBuildingids() {
        return Buildingids;
    }

    public void setBuildingids(Long[] buildingids) {
        Buildingids = buildingids;
    }
}

